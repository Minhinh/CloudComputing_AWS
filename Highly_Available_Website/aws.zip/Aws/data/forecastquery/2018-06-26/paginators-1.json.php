<?php
// This file was auto-generated from sdk-root/src/data/forecastquery/2018-06-26/paginators-1.json
return [ 'pagination' => [],];
