<?php
// This file was auto-generated from sdk-root/src/data/cloudcontrol/2021-09-30/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [],];
