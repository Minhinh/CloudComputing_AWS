<?php
// This file was auto-generated from sdk-root/src/data/iotdeviceadvisor/2020-09-18/paginators-1.json
return [ 'pagination' => [ 'ListSuiteDefinitions' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', ], 'ListSuiteRuns' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', ], ],];
