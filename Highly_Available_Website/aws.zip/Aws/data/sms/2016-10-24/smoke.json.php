<?php
// This file was auto-generated from sdk-root/src/data/sms/2016-10-24/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'GetConnectors', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'DeleteReplicationJob', 'input' => [ 'replicationJobId' => 'invalidId', ], 'errorExpectedFromService' => true, ], ],];
